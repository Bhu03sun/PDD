package com.classical_music.classical_music_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
